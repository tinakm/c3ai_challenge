# -*- coding: utf-8 -*-
"""
Created on Tue Nov 17 01:21:44 2020

@author: keyva
"""
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
import seaborn as sns
import os
#from functions.calculations.RungeKutta4 import rungeKutta

from model import *
import pickle

from functions.calculations.RBF_function import policy_RBF

# Read the optimized Beta and Alpha values


number_of_days=224
number_of_objectives=3
length_of_simulation=30
length_of_state_calcs=10

# coefs=pd.read_csv("C:/Users/keyva/OneDrive/Documents/A3AI/model/coef_1000.csv")
# BETA=coefs['Beta_daily']
# Beta_daily=[float(x) for x in BETA.iloc[0].replace('[','').replace(',','').replace(']','').split()]
# main_COVID_Beta_v2(Beta_daily, sigma=0.5, alpha=alpha, gamma1=0.5, gamma2=0.5, E_0=30, I1_0=20, I2_0=10, N=19000000, observed_df=df_new_cases['new_cases'])

Input_file_NY=pd.read_csv("C:/Users/keyva/OneDrive/Documents/A3AI/model/Final_NY_updated.csv")


def main_COVID_MODPS(b_radii_sv1,
                b_radii_sv2,
                b_radii_sv3,
                c_centers_sv1,
                c_centers_sv2,
                c_centers_sv3,
                weight_SI,
                weight_GRI,
                weight_CHI,
                weight_ESI):
    
    
    A_rbf=5 # number of RBFs
    B_stat=3 # Number of state variables, currently 1- month 2- confirmed cases  3- mobility
    K_policy=4 # Number of policies 
    
    
    b_radii=np.zeros((A_rbf, B_stat)) # radi
    c_centers=np.zeros((A_rbf, B_stat)) # centers
    weight_policy=np.zeros((A_rbf, K_policy)) # weights col-1= Spring Wheat col-2= Alfalfa col-3= Almond col-4= SilageCorn

    
    b_radii[:,0]=b_radii_sv1
    b_radii[:,1]=b_radii_sv2
    b_radii[:,2]=b_radii_sv3

    c_centers[:,0]=c_centers_sv1
    c_centers[:,1]=c_centers_sv2
    c_centers[:,2]=c_centers_sv3

    weight_policy[:,0]=weight_SI
    weight_policy[:,0]= weight_policy[:,0]/(sum(weight_policy[:,0]))
    
    weight_policy[:,1]=weight_GRI
    weight_policy[:,1]= weight_policy[:,1]/(sum(weight_policy[:,1])) 
    
    weight_policy[:,2]=weight_CHI
    weight_policy[:,2]= weight_policy[:,2]/(sum(weight_policy[:,2]))

    weight_policy[:,3]=weight_ESI
    weight_policy[:,3]= weight_policy[:,3]/(sum(weight_policy[:,3]))

    
    # First call the function and calculate the new cases
        
    # Select the first 14 days
    start_day=int(np.random.randint(0,(number_of_days-length_of_simulation-length_of_state_calcs), 1))
    
    # Construct the state vector
    max_mobility=Input_file_NY["ResidentialMobility"].max()
    average_mobility=Input_file_NY.loc[start_day:(start_day+length_of_state_calcs),"ResidentialMobility"].mean()
    normalized_mobility=max(min(1, average_mobility/max_mobility), 0.01) 
    
    max_confirmed_case=Input_file_NY["daily_ConfirmedCases"].max()
    average_confirmed_cases=Input_file_NY.loc[start_day:(start_day+length_of_state_calcs),"daily_ConfirmedCases"].mean()
    normalized_confirmed_case=max(min(1, average_confirmed_cases/max_confirmed_case), 0.01)
    
    normalized_month=Input_file_NY.loc[start_day:(start_day+length_of_state_calcs),"Month"].min()/12
    
    state_vector=np.array([normalized_mobility, normalized_confirmed_case, normalized_month])
        
    # SI
    Policy_StringencyIndex=policy_RBF(b_radii, c_centers, weight_policy[:,0], state_vector)
    # GRI
    Policy_GovernmentResponseIndex=policy_RBF(b_radii, c_centers, weight_policy[:,1], state_vector)
    # CHI
    Policy_ContainmentHealthIndex=policy_RBF(b_radii, c_centers, weight_policy[:,2], state_vector)
    # ESI
    Policy_EconomicSupportIndex=policy_RBF(b_radii, c_centers, weight_policy[:,3], state_vector)
   
    # Employ machine-learning to calculate OBJECTIVES
    
    # Input file for ML
    input_unemployment=Input_file_NY.iloc[(start_day+length_of_state_calcs):(start_day+length_of_simulation),np.r_[2:13, 14:21, 13]]
    input_fatalities=Input_file_NY.iloc[(start_day+length_of_state_calcs):(start_day+length_of_simulation),np.r_[2:13, 14:21, 22]]
    input_confirmedcases=Input_file_NY.iloc[(start_day+length_of_state_calcs):(start_day+length_of_simulation),np.r_[2:13, 14:22]]
    
    # Replace policies with optimized policies
    input_unemployment['StringencyIndex']=Policy_StringencyIndex*Input_file_NY["StringencyIndex"].max()
    input_unemployment['GovernmentResponseIndex']=Policy_GovernmentResponseIndex*Input_file_NY["GovernmentResponseIndex"].max()
    input_unemployment['ContainmentHealthIndex']=Policy_ContainmentHealthIndex*Input_file_NY["ContainmentHealthIndex"].max()
    input_unemployment['EconomicSupportIndex']=Policy_EconomicSupportIndex*Input_file_NY["EconomicSupportIndex"].max()


    Objective_df=pd.DataFrame(np.zeros((length_of_simulation, number_of_objectives)), columns=['Unimployment','Fatalities','ConfirmedCases'])

    # Load pickle models
    
    filename1 = 'ML_xgboost_model_1.sav'
    filename2 = 'ML_xgboost_model_2.sav'
    filename3 = 'ML_xgboost_model_3.sav'

    loaded_model1 = pickle.load(open(filename1, 'rb'))
    loaded_model2 = pickle.load(open(filename2, 'rb'))
    loaded_model3 = pickle.load(open(filename3, 'rb'))
    
    X_1 = input_fatalities.iloc[:, 0:18].values
    #y_1 = input_fatalities.iloc[:, 18].values

    X_2 = input_confirmedcases.iloc[:, 0:18].values
    #y_2 = input_confirmedcases.iloc[:, 18].values

    X_3 = input_unemployment.iloc[:, 0:18].values
    #y_3 = input_unemployment.iloc[:, 18].values

    result1 = loaded_model1.predict(X_1)
    result2 = loaded_model2.predict(X_2)
    result3 = loaded_model3.predict(X_3)


    Number_of_death=result1
    Number_of_cases_positive=result2
    Number_of_unemployed=result3

        
    #constraints

    return(result1.mean(), result2.mean(), result3.mean())



