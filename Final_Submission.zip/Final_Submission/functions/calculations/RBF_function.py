# -*- coding: utf-8 -*-
"""
Created on Tue Oct 13 22:24:15 2020

@author: keyva
"""

#------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------
#----------------------------FUNCTIONS-----------------------------------------------------------
        
#-------------------------- CALCULATE POLICY RELEASE


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
import os
import sys
import json


def policy_RBF(b_radii,             # a vector of radii used to construct the RBF
                c_centers,           # a vector of centers used to construct the RBF
                w_weight_crop,            # a vector of weights used to construct the RBF
                state_vector   # water stress index and crop price, and environmental conditions
                ): # policy prescribed area
    
        u_1=0
        A_rbf=c_centers[:,0].size #number of RBFs
        B_input=state_vector.size   #number of state variables
        
        for i in range(0, A_rbf): # i corresponds to the number of RBFs -- b_radii.shape[0]
            #print ("got here 1 \n i equals--"+ str(i))
            
            u_0=0
            for j in range(0, B_input-1): # j corresponds to the number of state variables -- b_radii.shape[1]
                u_0= u_0 + ((state_vector[j]-c_centers[i,j])**2)/b_radii[i,j]**2
                #print ("got here 2 \n j equals--"+ str(i))
                
            u_1 = u_1 + w_weight_crop[i]*np.exp(-u_0)
            
        return (u_1)


