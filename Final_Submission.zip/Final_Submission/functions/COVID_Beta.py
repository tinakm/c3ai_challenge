# -*- coding: utf-8 -*-
"""
Created on Tue Nov 17 01:21:44 2020

@author: keyva
"""
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
import seaborn as sns
import os
#from functions.calculations.RungeKutta4 import rungeKutta

rows_to_skip=60
number_of_days=238
number_of_col_main_df=9

OX_data=pd.read_csv('C:/Users/keyva/OneDrive/Documents/A3AI/model/summary_all_info_test_daily.csv')
OX_data_input_NY=OX_data.loc[OX_data["States"]=='NewYork','ConfirmedCases']
OX_data_input_NY_short=OX_data_input_NY[rows_to_skip:number_of_days+rows_to_skip+1]

for i in np.arange(1,len(OX_data_input_NY_short)-1):
    new_cases[i]=(OX_data_input_NY_short.iloc[i+1]-OX_data_input_NY_short.iloc[i])

df_new_cases=pd.DataFrame(new_cases, columns=['new_cases'])


def main_COVID_Beta_v2(Beta_daily,
         sigma=0.5,
         alpha=0.5,
         gamma1=0.2,
         gamma2=0.5,
         E_0=30,
         I1_0=20,
         I2_0=10,
         N=19000000,
         observed_df=df_new_cases['new_cases']):
    
    #print ('at least I got here ! ')

    main_df_sd=pd.DataFrame(np.zeros((len(Beta_daily), number_of_col_main_df)), columns=['S','E','F', 'f','I1', 'I2', 'R', 'Beta', 'new_cases'])
    main_df_sd['new_cases']=observed_df
    S_0=N
    R_0=0

    for i_t in np.arange((len(Beta_daily))):
        #print ('i_t=', i_t)
        if i_t==0:
            main_df_sd.loc[i_t,'S']=S_0-E_0-I1_0-I2_0-R_0
            main_df_sd.loc[i_t,'E']=E_0
            main_df_sd.loc[i_t,'I1']=I1_0
            main_df_sd.loc[i_t,'I2']=I2_0
            main_df_sd.loc[i_t,'R']=R_0
        
        else:
            Beta_t=Beta_daily[i_t] #main_df_sd[i_t,'Beta']
            S_t=main_df_sd.loc[i_t-1,'S']
            E_t=main_df_sd.loc[i_t-1,'E']
            I1_t=main_df_sd.loc[i_t-1,'I1']
            I2_t=main_df_sd.loc[i_t-1,'I2']
            
            if S_t==0:
                E_t=0
                I1_t=0
                I2_t=0
            else:
            # ---------------- CALCULATE FLUXES
                f_t=Beta_t*S_t/N*(I1_t+I2_t)**alpha
            
                d_E=f_t-sigma*E_t
                # Change in exposed population
            
                # Chnage in I1
                d_I1=sigma*E_t-gamma1*I1_t
                
                # Chnage in I2
                d_I2=gamma1*I1_t-gamma2*I2_t
                
                # Chnage in Recovered
                d_R=gamma2*I2_t
        
        
            # ------------------------ UPDATE SYSTEM STATES
            
            main_df_sd.loc[i_t,'f']= f_t
            main_df_sd.loc[i_t,'F']=main_df_sd.loc[i_t-1,'F'] + f_t
            main_df_sd.loc[i_t,'S']=main_df_sd.loc[i_t-1,'S']- f_t
            #if main_df_sd.loc[i_t,'S'] ==0:
            main_df_sd.loc[i_t,'S']=max(main_df_sd.loc[i_t,'S'], 0) #Makes sure it does not got below zero
            #    return
            main_df_sd.loc[i_t,'E']=main_df_sd.loc[i_t-1,'E']+d_E
            main_df_sd.loc[i_t,'I1']=main_df_sd.loc[i_t-1,'I1']+d_I1
            main_df_sd.loc[i_t,'I2']=main_df_sd.loc[i_t-1,'I2']+d_I2
            main_df_sd.loc[i_t,'R']=main_df_sd.loc[i_t-1,'R']+d_R
        
    objs = [0.0] * 1
    
    # The objective is to minimize sum of sum of squares
    objs[0]=(main_df_sd.loc[:,'f']-main_df_sd.loc[:,'new_cases'])**2
    error=objs[0].sum()
    #constraints

    return(error)



coefs=pd.read_csv("C:/Users/keyva/OneDrive/Documents/A3AI/model/coef_1000.csv")
BETA=coefs['Beta_daily']
Beta_daily=[float(x) for x in BETA.iloc[0].replace('[','').replace(',','').replace(']','').split()]
ALPHA=coefs['alpha'].values
df_out=main_COVID_Beta_v2(Beta_daily, sigma=0.5, alpha=ALPHA, gamma1=0.5, gamma2=0.5, E_0=30, I1_0=20, I2_0=10, N=19000000, observed_df=df_new_cases['new_cases'])

main_COVID_Beta_v2(Beta_daily, sigma=0.5, alpha=alpha, gamma1=0.2, gamma2=0.5, E_0=30, I1_0=20, I2_0=10, N=19000000, observed_df=df_new_cases['new_cases'])
sns.lineplot(y=observed_df, x=np.arange(0, len(observed_df)))
sns.lineplot(y=df_out.loc[:,'f'], x=np.arange(0, len(observed_df)))
