# -*- coding: utf-8 -*-
"""
Created on Wed Nov 18 23:50:07 2020

@author: keyva
"""

import xgboost as xgb

from sklearn.metrics import mean_squared_error
import pandas as pd
import numpy as np
import random
from sklearn.model_selection import train_test_split
import pickle


Input_file_NY=pd.read_csv("C:/Users/keyva/OneDrive/Documents/A3AI/model/Final_NY_updated.csv")

# dataset_ML1 =  pd.read_csv("/home/fs02/pmr82_0001/tk662/TestRuns/data_ML1.csv", index_col=0,delimiter='\t')
# dataset_ML2 =  pd.read_csv("/home/fs02/pmr82_0001/tk662/TestRuns/data_ML2.csv", index_col=0,delimiter='\t')
# dataset_ML3 =  pd.read_csv("/home/fs02/pmr82_0001/tk662/TestRuns/data_ML3.csv", index_col=0,delimiter='\t')

dataset_ML1=Input_file_NY.iloc[:,np.r_[2:13, 14:21, 22]]
dataset_ML2=Input_file_NY.iloc[:,np.r_[2:13, 14:22]]
dataset_ML3=Input_file_NY.iloc[:,np.r_[2:13, 14:21, 13]]


X_ml1 = dataset_ML1.iloc[:, 0:18].values
y_ml1 = dataset_ML1.iloc[:, 18].values

X_ml2 = dataset_ML2.iloc[:, 0:18].values
y_ml2 = dataset_ML2.iloc[:, 18].values

X_ml3 = dataset_ML3.iloc[:, 0:18].values
y_ml3 = dataset_ML3.iloc[:, 18].values


ml1_dmatrix = xgb.DMatrix(data=X_ml1,label=y_ml1)
ml2_dmatrix = xgb.DMatrix(data=X_ml2,label=y_ml2)
ml3_dmatrix = xgb.DMatrix(data=X_ml3,label=y_ml3)

random.seed(567)

X_train_ml1, X_test_ml1, y_train_ml1, y_test_ml1 = train_test_split(X_ml1, y_ml1, test_size = 0.1,  shuffle=False)
X_train_ml2, X_test_ml2, y_train_ml2, y_test_ml2 = train_test_split(X_ml2, y_ml2, test_size = 0.1,  shuffle=False)
X_train_ml3, X_test_ml3, y_train_ml3, y_test_ml3 = train_test_split(X_ml3, y_ml3, test_size = 0.1,  shuffle=False)


xg_reg_ml1 = xgb.XGBRegressor()
xg_reg_ml2 = xgb.XGBRegressor()
xg_reg_ml3 = xgb.XGBRegressor()


xg_reg_ml1.fit(X_train_ml1,y_train_ml1)
xg_reg_ml2.fit(X_train_ml2,y_train_ml2)
xg_reg_ml3.fit(X_train_ml3,y_train_ml3)


preds_ml1 = xg_reg_ml1.predict(X_test_ml1)
preds_ml2 = xg_reg_ml2.predict(X_test_ml2)
preds_ml3 = xg_reg_ml3.predict(X_test_ml3)


rmse_ml1 = np.sqrt(mean_squared_error(y_test_ml1, preds_ml1))
rmse_ml2 = np.sqrt(mean_squared_error(y_test_ml2, preds_ml2))
rmse_ml3 = np.sqrt(mean_squared_error(y_test_ml3, preds_ml3))

print("RMSE: %f" % (rmse_ml1))
print("RMSE: %f" % (rmse_ml2))
print("RMSE: %f" % (rmse_ml3))
 
filename1 = 'ML_xgboost_model_1.sav'
filename2 = 'ML_xgboost_model_2.sav'
filename3 = 'ML_xgboost_model_3.sav'

pickle.dump(xg_reg_ml1, open(filename1, 'wb'))
pickle.dump(xg_reg_ml2, open(filename2, 'wb'))
pickle.dump(xg_reg_ml3, open(filename3, 'wb'))

