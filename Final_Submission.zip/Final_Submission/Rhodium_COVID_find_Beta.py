# -*- coding: utf-8 -*-
"""
Created on Wed May 20 18:09:51 2020

@author: keyva
"""

Rhodium_Folder="C:/Users/keyva/OneDrive/Documents/papers/CropAcreage/Code/Rhodium/Rhodium"
Model_Folder="C:/Users/keyva/OneDrive/Documents/A3AI/model"


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
import os
import sys
import json
import math
import datetime


#os.chdir("C:/Users/keyva/OneDrive/Documents/papers/CropAcreage/Code/Rhodium/Rhodium")
os.chdir(Rhodium_Folder)

#import Rhodium
from rhodium import *

os.chdir(Model_Folder)
os.getcwd()

from functions.COVID_model import main_COVID_Beta
# import model
#pd.read_csv('Seed_1_output.csv')


# plotting options
%matplotlib inline
sns.set()
sns.set_style('darkgrid')

#------------------------------------------------ model
from scipy.optimize import brentq as root


#----------------------------------- Rhodium model


    
#model_COVID_Beta = Model(main_COVID_Beta)
model_COVID_Beta = Model(main_COVID_Beta_v2)

#main_COVID_Beta_v2(Beta_daily, sigma=0.1, alpha=0.1, gamma1=0.1, gamma2=0.1, E_0=30, I1_0=20, I2_0=10, N=1000, observed_df=df_new_cases['new_cases'])


model_COVID_Beta.parameters = [Parameter("Beta_daily"),
                    Parameter("sigma"),
                    Parameter("alpha"),
                    Parameter("gamma1"),
                    Parameter("gamma2"),
                    Parameter("E_0"),
                    Parameter("I1_0"),
                    Parameter("I2_0"),
                    Parameter("N"),
                    Parameter("observed_df")]

 
model_COVID_Beta.responses = [Response("error", Response.MINIMIZE)]
                        # Response("GW_level", Response.MAXIMIZE),
                        # Response("Orchard_Reliability", Response.MAXIMIZE),
                        # Response("Max_yield_reliability", Response.MAXIMIZE)]

#---------------------- constraints

model_COVID_Beta.constraints = []

#------------------ Levers

model_COVID_Beta.levers = [RealLever("Beta_daily", 0.0, 100.0, length=238),
                           RealLever("alpha", 0.0, 2.0, length=1)]


#model.levers = [RealLever("pollution_limit", 0.0, 0.1, length=100)]


#----------------- Optimize

output_COVID_Beta = optimize(model_COVID_Beta, "NSGAII",  10000)
output_COVID_Beta.save('C:/Users/keyva/OneDrive/Documents/A3AI/model/coef_1000.csv')
print("Found", len(output_COVID_Beta), "optimal policies!")


#----------------- Optimize

output_COVID_Beta = optimize(model_COVID_Beta, "NSGAII",  10000)
output_COVID_Beta.save('C:/Users/keyva/OneDrive/Documents/A3AI/model/coef_1000.csv')
print("Found", len(output_COVID_Beta), "optimal policies!")
