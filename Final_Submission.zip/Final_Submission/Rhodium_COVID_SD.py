# -*- coding: utf-8 -*-
"""
Created on Wed May 20 18:09:51 2020

@author: keyva
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
import os
import sys
import json
import math
import datetime


os.chdir("C:/Users/keyva/OneDrive/Documents/papers/CropAcreage/Code/Rhodium/Rhodium")

#import scipy
from rhodium import *

#from rhodium import *

# plotting options
%matplotlib inline
sns.set()
sns.set_style('darkgrid')

#------------------------------------------------ model
from scipy.optimize import brentq as root


#----------------------------------- Rhodium model
    
model_crop = Model(main_ag_dec)

model_crop.parameters = [Parameter("b_radii_season_sv1"),
                    Parameter("b_radii_season_sv2"),
                    Parameter("b_radii_season_sv3"),
                    Parameter("c_centers_season_sv1"),
                    Parameter("c_centers_season_sv2"),
                    Parameter("c_centers_season_sv3"),
                    Parameter("b_radii_month_sv1"),
                    Parameter("b_radii_month_sv2"),
                    Parameter("b_radii_month_sv3"),
                    Parameter("b_radii_month_sv4"),
                    Parameter("c_centers_month_sv1"),
                    Parameter("c_centers_month_sv2"),
                    Parameter("c_centers_month_sv3"),
                    Parameter("c_centers_month_sv4"),
                    Parameter("weight_area_crop1"),
                    Parameter("weight_area_crop2"),
                    Parameter("weight_area_crop3"),
                    Parameter("weight_area_crop4"),
                    Parameter("weight_deficit_crop1"),
                    Parameter("weight_deficit_crop2"),
                    Parameter("weight_deficit_crop3"),
                    Parameter("weight_deficit_crop4"),
                    Parameter("weight_water_trade_sell"),
                    Parameter("weight_water_trade_buy"),
                    Parameter("weight_GW_recharge"),
                    Parameter("weight_GW_extract")]

 #Average_revenue     GW_level  Orchard_Reliability  Max_yield_reliability
 
model_crop.responses = [Response("Average_revenue", Response.MAXIMIZE),
                        Response("GW_level", Response.MAXIMIZE),
                        Response("Orchard_Reliability", Response.MAXIMIZE),
                        Response("Max_yield_reliability", Response.MAXIMIZE)]

#---------------------- constraints

model_crop.constraints = [Constraint("Average_revenue >= 0")]

#model_crop.constraints = []

#------------------ Levers

# model.levers = [RealLever(b_radii_season,  0.0, 0.1, length=100), 
#                 RealLever(c_centers_season,  0.0, 0.1, length=100),
#                 RealLever(b_radii_month,  0.0, 0.1, length=100),
#                 RealLever(c_centers_month,  0.0, 0.1, length=100),
#                 RealLever(weight_area,  0.0, 0.1, length=100),
#                 RealLever(weight_deficit,  0.0, 0.1, length=100),
#                 RealLever(weight_water_trade,  0.0, 0.1, length=100),
#                 RealLever(weight_GW,  0.0, 0.1, length=100)]

model_crop.levers =[ RealLever("b_radii_season_sv1", 0.01, 1.0, length=7), 
                RealLever("b_radii_season_sv2", 0.01, 1.0, length=7), 
                RealLever("b_radii_season_sv3", 0.01, 1.0, length=7), 
                RealLever("c_centers_season_sv1", 0.01, 1.0, length=7), 
                RealLever("c_centers_season_sv2", 0.01, 1.0, length=7), 
                RealLever("c_centers_season_sv3", 0.01, 1.0, length=7), 
                RealLever("b_radii_month_sv1", 0.01, 1.0, length=7), 
                RealLever("b_radii_month_sv2", 0.01, 1.0, length=7), 
                RealLever("b_radii_month_sv3", 0.01, 1.0, length=7), 
                RealLever("b_radii_month_sv4", 0.01, 1.0, length=7), 
                RealLever("c_centers_month_sv1", 0.01, 1.0, length=7), 
                RealLever("c_centers_month_sv2", 0.01, 1.0, length=7), 
                RealLever("c_centers_month_sv3", 0.01, 1.0, length=7), 
                RealLever("c_centers_month_sv4", 0.01, 1.0, length=7), 
                RealLever("weight_area_crop1", 0.01, 1.0, length=7), 
                RealLever("weight_area_crop2", 0.01, 1.0, length=7), 
                RealLever("weight_area_crop3", 0.01, 1.0, length=7), 
                RealLever("weight_area_crop4", 0.01, 1.0, length=7), 
                RealLever("weight_deficit_crop1", 0.01, 1.0, length=7), 
                RealLever("weight_deficit_crop2", 0.01, 1.0, length=7), 
                RealLever("weight_deficit_crop3", 0.01, 1.0, length=7), 
                RealLever("weight_deficit_crop4", 0.01, 1.0, length=7), 
                RealLever("weight_water_trade_sell", 0.01, 1.0, length=7), 
                RealLever("weight_water_trade_buy", 0.01, 1.0, length=7), 
                RealLever("weight_GW_recharge", 0.01, 1.0, length=7), 
                RealLever("weight_GW_extract",0.01, 1.0, length=7)]


#model.levers = [RealLever("pollution_limit", 0.0, 0.1, length=100)]

#----------------- Optimize

output_crop = optimize(model_crop, "NSGAII", 10)
#out_old=output_crop
output_crop.save("C:/Users/keyva/OneDrive/Documents/papers/CropAcreage/Code/Rhodium/initial_output_new.csv")
print("Found", len(output_crop), "optimal policies!")

#-------------- policy

policy = output_crop[:]
policy = output_crop.find_max("Average_revenue")
policies = output_crop.find("Average_revenue > 0.0")

len(policies)
#--------------- Policy select

policy = output_crop.find_max("Orchard_Reliability")

print("Average_revenue:", policy["Average_revenue"])
print("GW_level:               ", policy["GW_level"])
print("Orchard_Reliability:               ", policy["Orchard_Reliability"])
print("Max_yield_reliability:           ", policy["Max_yield_reliability"])

#----------------- post process

# result = output_crop.apply("sum(pollution_limit)")

# #----------------

# output.apply("total_pollution = sum(pollution_limit)");
# policy = output.find_min("total_pollution")

#-----------------

# df = output.as_dataframe()
# arr = output.as_array()

#----------------- Figures

fig = scatter2d(model_crop, output_crop)

#----------------

fig = scatter2d(model_crop, output_crop, c="Average_revenue")

#-----------------

fig = scatter2d(model_crop, output_crop,
                brush=[Brush("Orchard_Reliability > 0.2"), Brush("Orchard_Reliability <= 0.2")])

#-----------------

fig = scatter3d(model_crop, output_crop, c="Average_revenue",
                brush=[Brush("Orchard_Reliability > 0.2"), Brush("Orchard_Reliability <= 0.2")])

#-----------------

fig = pairs(model_crop, output_crop,
            brush=[Brush("Orchard_Reliability > 0.2"), Brush("Orchard_Reliability <= 0.2")])

#--------------------

fig = parallel_coordinates(model_crop, output_crop, colormap="rainbow", target="top")
fig.set_size_inches(10, 8)
fig.savefig("figures/figure_1.png")

#--------------------

fig = parallel_coordinates(model_crop, output_crop, target="top",
                           brush=[Brush("Orchard_Reliability > 0.2"), Brush("Orchard_Reliability <= 0.2")])

#--------------------- Scenario Discovry

policy = {"pollution_limit" : [0.02]*100}

#-----------------------

result = evaluate(model, policy)

print("Max Phosphorus in Lake:", result["max_P"])
print("Utility:               ", result["utility"])
print("Inertia:               ", result["inertia"])
print("Reliability:           ", result["reliability"])

#------------------------ define uncertainties

model.uncertainties = [UniformUncertainty("b", 0.1, 0.45),
                       UniformUncertainty("q", 2.0, 4.5),
                       UniformUncertainty("mean", 0.01, 0.05),
                       UniformUncertainty("stdev", 0.001, 0.005),
                       UniformUncertainty("delta", 0.93, 0.99)]


#---------------------- SOWs

SOWs = sample_lhs(model, 1000)

#----------------------

results = evaluate(model, update(SOWs, policy))

#----------------------

classification = results.apply("'Reliable' if reliability > 0.9 else 'Unreliable'")

#-------------------

p = Prim(results, classification, include=model.uncertainties.keys(), coi="Reliable")
box = p.find_box()
fig = box.show_tradeoff()

#----------------------------------

print(box)

#---------------------------- CART

c = Cart(results, classification, include=model.uncertainties.keys(), min_samples_leaf=50)
c.show_tree()

#-------------------------

c.print_tree(coi="Reliable")

#----------------------- Sensitivity Analysis

result = sa(model, "reliability", policy=policy, method="morris", nsamples=1000, num_levels=4, grid_jump=2)
print(result)

#--------------------

result = sa(model, "reliability", policy=policy, method="sobol", nsamples=10000)
print(result)

#-------------------

fig = result.plot()

#--------------

fig = result.plot_sobol(threshold=0.01)

#---------------

fig = result.plot_sobol(threshold=0.01,
                        groups={"Lake Parameters" : ["b", "q"],
                                "Natural Pollution" : ["mean", "stdev"],
                                "Discounting" : ["delta"]})

#--------------------

fig = oat(model, "reliability", policy=policy, nsamples=1000)

#---------------------

