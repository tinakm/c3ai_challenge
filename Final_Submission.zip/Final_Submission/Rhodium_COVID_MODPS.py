# -*- coding: utf-8 -*-
"""
Created on Wed May 20 18:09:51 2020

@author: keyva
"""

Rhodium_Folder="C:/Users/keyva/OneDrive/Documents/papers/CropAcreage/Code/Rhodium/Rhodium"
Model_Folder="C:/Users/keyva/OneDrive/Documents/A3AI/model"

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
import os
import sys
import json
import math
import datetime


os.chdir(Rhodium_Folder)

#import Rhodium
from rhodium import *

os.chdir(Model_Folder)
os.chdir(Model_Folder)

from functions import *
# import model
#pd.read_csv('Seed_1_output.csv')


# plotting options
%matplotlib inline
sns.set()
sns.set_style('darkgrid')

#------------------------------------------------ model
from scipy.optimize import brentq as root


#----------------------------------- Rhodium model

    
model_COVID = Model(main_COVID_MODPS)

model_COVID.parameters = [Parameter("b_radii_sv1"),
                    Parameter("b_radii_sv2"),
                    Parameter("b_radii_sv3"),
                    Parameter("c_centers_sv1"),
                    Parameter("c_centers_sv2"),
                    Parameter("c_centers_sv3"),
                    Parameter("weight_SI"),
                    Parameter("weight_GRI"),
                    Parameter("weight_CHI"),
                    Parameter("weight_ESI")]

 #Average_revenue     GW_level  Orchard_Reliability  Max_yield_reliability
 
model_COVID.responses = [Response("Fatalities", Response.MINIMIZE),
                        Response("Confirmed_Cases", Response.MINIMIZE),
                        Response("Unemployment_Rate", Response.MINIMIZE)]

#---------------------- constraints

#model_crop.constraints = [Constraint("Average_revenue >= 0")]

#model_crop.constraints = []

#------------------ Levers

model_COVID.levers =[ RealLever("b_radii_sv1", 0.01, 1.0, length=5), 
                RealLever("b_radii_sv2", 0.01, 1.0, length=5), 
                RealLever("b_radii_sv3", 0.01, 1.0, length=5), 
                RealLever("c_centers_sv1", 0.01, 1.0, length=5), 
                RealLever("c_centers_sv2", 0.01, 1.0, length=5), 
                RealLever("c_centers_sv3", 0.01, 1.0, length=5), 
                RealLever("weight_SI", 0.01, 1.0, length=5), 
                RealLever("weight_GRI", 0.01, 1.0, length=5), 
                RealLever("weight_CHI", 0.01, 1.0, length=5), 
                RealLever("weight_ESI", 0.01, 1.0, length=5)]




#----------------- Optimize

output_COVID = optimize(model_COVID, "NSGAII", 100000)

#---------------- Save outputs

output_COVID.save(Model_Folder + "/Output_COVID_MODPS_Policies.csv")


print("Found", len(output_COVID), "optimal policies!")

#-------------- policy

policy = output_crop[:]
policy = output_crop.find_max("Fatalities")
policies = output_crop.find_min("Confirmed_Cases")

len(policies)
#--------------- Policy select

#policy = output_crop.find_max("Orchard_Reliability")

print("Fatalities:", policy["Fatalities"])
print("Confirmed_Cases:               ", policy["Confirmed_Cases"])
print("Unemployment_Rate:               ", policy["Unemployment_Rate"])

#----------------- post process

# df = output.as_dataframe()
# arr = output.as_array()

#----------------- Figures

fig1 = scatter2d(model_COVID, output_COVID)
fig1.set_size_inches(10, 8)
fig1.savefig(Model_Folder + "/Figures/figure_1.png")
#----------------

fig2 = scatter2d(model_COVID, output_COVID, c="Fatalities")
fig2.set_size_inches(10, 8)
fig2.savefig(Model_Folder + "/Figures/figure_2.png")

#-----------------
